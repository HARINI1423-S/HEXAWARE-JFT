package com.Hexaware.CaseStudy.CRS.test;

import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepository;
import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepositoryImpl;
import com.Hexaware.CaseStudy.CRS.exceptions.CarNotFoundException;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CarNotFoundTest {

    @Test
    void testCarNotFoundExceptionThrown() {
        ICarLeaseRepository dao = new ICarLeaseRepositoryImpl();

        Exception exception = assertThrows(CarNotFoundException.class, () -> {
            dao.findCarById(9999);
        });

        assertEquals("Vehicle with ID 9999 not found.", exception.getMessage());
    }
}
