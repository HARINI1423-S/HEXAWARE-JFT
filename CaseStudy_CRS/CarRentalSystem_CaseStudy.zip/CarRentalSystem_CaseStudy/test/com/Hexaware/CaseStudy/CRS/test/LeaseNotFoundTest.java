package com.Hexaware.CaseStudy.CRS.test;

import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepository;
import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepositoryImpl;
import com.Hexaware.CaseStudy.CRS.exceptions.LeaseNotFoundException;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LeaseNotFoundTest {

    @Test
    void testLeaseNotFoundExceptionThrown() {
        ICarLeaseRepository dao = new ICarLeaseRepositoryImpl();

        Exception exception = assertThrows(LeaseNotFoundException.class, () -> {
            dao.findLeaseById(9999); 
        });

        assertEquals("Lease not found.", exception.getMessage());
    }
}
