package com.Hexaware.CaseStudy.CRS.test;

import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepository;
import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepositoryImpl;
import com.Hexaware.CaseStudy.CRS.exceptions.CustomerNotFoundException;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CustomerNotFoundTest {

    @Test
    void testCustomerNotFoundExceptionThrown() {
        ICarLeaseRepository dao = new ICarLeaseRepositoryImpl();

        Exception exception = assertThrows(CustomerNotFoundException.class, () -> {
            dao.findCustomerById(999); // Assuming ID 999 does not exist
        });

        assertEquals("Customer not found.", exception.getMessage());
    }
}
