package com.Hexaware.CaseStudy.CRS.test;

import com.Hexaware.CaseStudy.CRS.entity.Lease;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class LeaseRetrievalTest {

    @Test
    void testLeaseRetrievalSuccessfully() {
        Lease lease = new Lease(
                302,
                102,
                202,
                LocalDate.of(2025, 4, 1),
                LocalDate.of(2025, 4, 5),
                "Weekly"
        );

        lease.setReturnDate(java.sql.Date.valueOf("2025-04-05"));
        lease.setTotalAmount(1250.0);

        assertNotNull(lease);
        assertEquals(302, lease.getLeaseID());
        assertEquals(102, lease.getVehicleID());
        assertEquals(202, lease.getCustomerID());
        assertEquals("2025-04-01", lease.getStartDate().toString());
        assertEquals("2025-04-05", lease.getEndDate().toString());
        assertEquals("2025-04-05", lease.getReturnDate().toString());
        assertEquals(1250.0, lease.getTotalAmount());
        assertEquals("Weekly", lease.getType());
    }
}
