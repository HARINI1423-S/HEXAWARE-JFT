package com.Hexaware.CaseStudy.CRS.test;

import com.Hexaware.CaseStudy.CRS.entity.Lease;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class LeaseCreationTest {

    @Test
    void testLeaseCreationSuccessfully() {
        Lease lease = new Lease(
                301,
                101,
                201,
                LocalDate.of(2025, 4, 10),
                LocalDate.of(2025, 4, 15),
                LocalDate.of(2025, 4, 14),
                2750.0,
                "Daily"
        );

        assertEquals(301, lease.getLeaseID());
        assertEquals(101, lease.getVehicleID());
        assertEquals(201, lease.getCustomerID());
        assertEquals("2025-04-10", lease.getStartDate().toString());
        assertEquals("2025-04-15", lease.getEndDate().toString());
        assertEquals("2025-04-14", lease.getReturnDate().toString());
        assertEquals(2750.0, lease.getTotalAmount());
        assertEquals("Daily", lease.getType());
    }
}
