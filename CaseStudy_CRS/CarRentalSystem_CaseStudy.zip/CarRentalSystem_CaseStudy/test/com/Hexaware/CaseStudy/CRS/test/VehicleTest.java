package com.Hexaware.CaseStudy.CRS.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.Hexaware.CaseStudy.CRS.entity.Vehicle;

public class VehicleTest {

    @Test
    void testAddCarSuccessfully() {
        Vehicle car = new Vehicle(101, "Toyota", "Camry", 2022, 55.0, "available", 5, 2.5f);

        assertEquals(101, car.getVehicleID());
        assertEquals("Toyota", car.getMake());
        assertEquals("Camry", car.getModel());
        assertEquals(2022, car.getYear());
        assertEquals(55.0, car.getDailyRate());
        assertEquals("available", car.getStatus());
        assertEquals(5, car.getPassengerCapacity());
        assertEquals(2.5f, car.getEngineCapacity());
    }

    @Test
    void testVehicleToString() {
        Vehicle car = new Vehicle(102, "Honda", "Civic", 2021, 60.0, "available", 4, 1.8f);
        String output = car.toString();

        assertTrue(output.contains("vehicleID=102"));
        assertTrue(output.contains("make='Honda'"));
        assertTrue(output.contains("model='Civic'"));
        assertTrue(output.contains("year=2021"));
        assertTrue(output.contains("dailyRate=60.0"));
        assertTrue(output.contains("status='available'"));
        assertTrue(output.contains("passengerCapacity=4"));
        assertTrue(output.contains("engineCapacity=1.8"));
    }
}
