module CarRentalSystem_CaseStudy {
	requires java.sql;
	requires org.junit.jupiter.api;
//    requires org.junit.jupiter.engine;
   

    // Export your packages if needed:
    exports com.Hexaware.CaseStudy.CRS.main;
    exports com.Hexaware.CaseStudy.CRS.util;
    exports com.Hexaware.CaseStudy.CRS.dao;
    exports com.Hexaware.CaseStudy.CRS.entity;
    exports com.Hexaware.CaseStudy.CRS.exceptions;
}