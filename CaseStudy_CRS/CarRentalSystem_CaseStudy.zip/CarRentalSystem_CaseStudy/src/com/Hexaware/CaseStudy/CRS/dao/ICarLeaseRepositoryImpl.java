package com.Hexaware.CaseStudy.CRS.dao;

import com.Hexaware.CaseStudy.CRS.entity.*;
import com.Hexaware.CaseStudy.CRS.exceptions.*;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.*;
import java.util.*;

public class ICarLeaseRepositoryImpl implements ICarLeaseRepository {
    private final Connection conn;

    public ICarLeaseRepositoryImpl() {
        this.conn = com.Hexaware.CaseStudy.CRS.util.DBConnUtil.getConnection("db.properties");
    }

    // Vehicle Management 

    @Override
    public void addCar(Vehicle car) {
        String query = "INSERT INTO Vehicle(make, model, year, dailyRate, status, passengerCapacity, engineCapacity) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, car.getMake());
            ps.setString(2, car.getModel());
            ps.setInt(3, car.getYear());
            ps.setDouble(4, car.getDailyRate());
            ps.setString(5, car.getStatus());
            ps.setInt(6, car.getPassengerCapacity());
            ps.setFloat(7, car.getEngineCapacity());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void removeCar(int carID) {
        String query = "DELETE FROM Vehicle WHERE vehicleID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, carID);
            if (ps.executeUpdate() == 0) throw new CarNotFoundException("Vehicle not found.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Vehicle> listAvailableCars() {
        List<Vehicle> vehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicle WHERE status = 'available'";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                vehicles.add(mapVehicle(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return vehicles;
    }

    @Override
    public List<Vehicle> listRentedCars() {
        List<Vehicle> vehicles = new ArrayList<>();
        String query = "SELECT * FROM Vehicle WHERE status = 'notAvailable'";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                vehicles.add(mapVehicle(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return vehicles;
    }

    @Override
    public Vehicle findCarById(int carID) {
        String query = "SELECT * FROM Vehicle WHERE vehicleID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, carID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapVehicle(rs);
            else throw new CarNotFoundException("Vehicle with ID " + carID + " not found.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //Customer Management

    @Override
    public void addCustomer(Customer customer) {
        String query = "INSERT INTO Customer(firstName, lastName, email, phoneNumber) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, customer.getFirstName());
            ps.setString(2, customer.getLastName());
            ps.setString(3, customer.getEmail());
            ps.setString(4, customer.getPhoneNumber());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void removeCustomer(int customerID) {
        String query = "DELETE FROM Customer WHERE customerID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, customerID);
            if (ps.executeUpdate() == 0) throw new CustomerNotFoundException("Customer not found.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Customer> listCustomers() {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                customers.add(new Customer(
                    rs.getInt("customerID"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("email"),
                    rs.getString("phoneNumber")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customers;
    }

    @Override
    public Customer findCustomerById(int customerID) {
        String query = "SELECT * FROM Customer WHERE customerID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, customerID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Customer(
                    rs.getInt("customerID"),
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("email"),
                    rs.getString("phoneNumber")
                );
            } else throw new CustomerNotFoundException("Customer not found.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Lease Management

    @Override
    public Lease createLease(int customerId, int carId, LocalDate startDate, LocalDate endDate) {
        String insert = "INSERT INTO Lease(vehicleID, customerID, startDate, endDate, type) VALUES (?, ?, ?, ?, 'Daily')";
        try (PreparedStatement ps = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, carId);
            ps.setInt(2, customerId);
            ps.setDate(3, Date.valueOf(startDate));
            ps.setDate(4, Date.valueOf(endDate));
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                int leaseId = keys.getInt(1);
                updateVehicleStatus(carId, "notAvailable");
                return new Lease(leaseId, carId, customerId, startDate, endDate, "Daily");
            } else throw new RuntimeException("Lease creation failed.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Lease returnCar(int leaseId) {
        Lease lease = findLeaseById(leaseId);
        LocalDate today = LocalDate.now();
        Date returnDate = Date.valueOf(today);

        long days = ChronoUnit.DAYS.between(lease.getStartDate().toLocalDate(), today);
        double ratePerDay = findCarById(lease.getVehicleID()).getDailyRate();
        double totalAmount = days * ratePerDay;

        String query = "UPDATE Lease SET returnDate = ?, totalAmount = ? WHERE leaseID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setDate(1, returnDate);
            ps.setDouble(2, totalAmount);
            ps.setInt(3, leaseId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        updateVehicleStatus(lease.getVehicleID(), "available");
        lease.setReturnDate(returnDate);
        lease.setTotalAmount(totalAmount);
        return lease;
    }

    @Override
    public List<Lease> listActiveLeases() {
        List<Lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Lease WHERE endDate >= CURRENT_DATE";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                leases.add(mapLease(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return leases;
    }

    @Override
    public List<Lease> listLeaseHistory() {
        List<Lease> leases = new ArrayList<>();
        String query = "SELECT leaseID, vehicleID, customerID, startDate, endDate, return_date AS returnDate, type, totalAmount FROM Lease";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                leases.add(mapLease(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return leases;
    }


    @Override
    public Lease findLeaseById(int leaseID) {
        String query = "SELECT * FROM Lease WHERE leaseID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, leaseID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapLease(rs);
            else throw new LeaseNotFoundException("Lease not found.");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Payment Handling

    @Override
    public void recordPayment(Lease lease, double amount) {
        String query = "INSERT INTO Payment(leaseID, paymentDate, amount) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, lease.getLeaseID());
            ps.setDate(2, Date.valueOf(LocalDate.now()));
            ps.setDouble(3, amount);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    

    private Vehicle mapVehicle(ResultSet rs) throws SQLException {
        return new Vehicle(
            rs.getInt("vehicleID"),
            rs.getString("make"),
            rs.getString("model"),
            rs.getInt("year"),
            rs.getDouble("dailyRate"),
            rs.getString("status"),
            rs.getInt("passengerCapacity"),
            rs.getFloat("engineCapacity")
        );
    }

    private Lease mapLease(ResultSet rs) throws SQLException {
        Lease lease = new Lease(
            rs.getInt("leaseID"),
            rs.getInt("vehicleID"),
            rs.getInt("customerID"),
            rs.getDate("startDate").toLocalDate(),
            rs.getDate("endDate").toLocalDate(),
            rs.getString("type")
        );

        Date returnDate = rs.getDate("returnDate");
        if (returnDate != null) {
            lease.setReturnDate(returnDate); 

        }

        lease.setTotalAmount(rs.getDouble("totalAmount"));
        return lease;
    }
    
    @Override
    public List<Payment> listAllPayments() {
        List<Payment> payments = new ArrayList<>();
        String query = "SELECT * FROM Payment";
        
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Payment payment = new Payment(
                    rs.getInt("paymentID"),
                    rs.getInt("leaseID"),
                    rs.getDate("paymentDate"), // ✅ Correct type
                    rs.getDouble("amount")
                );
                payments.add(payment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return payments;
    }


    

    private void updateVehicleStatus(int vehicleID, String status) {
        String query = "UPDATE Vehicle SET status = ? WHERE vehicleID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, status);
            ps.setInt(2, vehicleID);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}