package com.Hexaware.CaseStudy.CRS.main;

import com.Hexaware.CaseStudy.CRS.dao.ICarLeaseRepositoryImpl;
import com.Hexaware.CaseStudy.CRS.entity.*;
import com.Hexaware.CaseStudy.CRS.exceptions.*;
import com.Hexaware.CaseStudy.CRS.util.*;

import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {Connection conn = DBConnUtil.getConnection("db.properties");
        ICarLeaseRepositoryImpl repo = new ICarLeaseRepositoryImpl();

            Scanner sc = new Scanner(System.in);
            int choice;
            do {
                System.out.println("\n========= Car Lease Management =========");
                System.out.println("1. Add Vehicle");
                System.out.println("2. Remove Vehicle");
                System.out.println("3. List Available Vehicles");
                System.out.println("4. List Rented Vehicles");
                System.out.println("5. Find Vehicle by ID");
                System.out.println("6. Add Customer");
                System.out.println("7. Remove Customer");
                System.out.println("8. List Customers");
                System.out.println("9. Find Customer by ID");
                System.out.println("10. Create Lease");
                System.out.println("11. Return Vehicle");
                System.out.println("12. List Active Leases");
                System.out.println("13. Lease History");
                System.out.println("14. Record Payment");
                System.out.println("15. List All Payment");
                System.out.println("16. List Payments By CustomerId");
                System.out.println("17. Total Revenue");
                System.out.println("18. Active Lease By CustomerId");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();

                switch (choice) {
                    case 1 -> {
                        System.out.print("Make: "); String make = sc.next();
                        System.out.print("Model: "); String model = sc.next();
                        System.out.print("Year: "); int year = sc.nextInt();
                        System.out.print("Rate: "); double rate = sc.nextDouble();
                        System.out.print("Capacity: "); int cap = sc.nextInt();
                        System.out.print("Engine: "); float eng = sc.nextFloat();
                        Vehicle v = new Vehicle(0, make, model, year, rate, "available", cap, eng);
                        repo.addCar(v);
                        System.out.println("Vehicle added successfully.");
                    }
                    case 2 -> {
                        System.out.print("Vehicle ID: ");
                        int id = sc.nextInt();
                        repo.removeCar(id);
                        System.out.println("Vehicle with ID " + id + " has been removed.");
                    }
                    case 3 -> {
                        List<Vehicle> availableCars = repo.listAvailableCars();
                        if (availableCars.isEmpty()) { 
                        	System.out.println("No available vehicles.");
                        }
                        
                        else { availableCars.forEach(System.out::println);
                    }
                    }
                    case 4 -> {
                        List<Vehicle> rentedCars = repo.listRentedCars();
                        if (rentedCars.isEmpty()) {
                        	System.out.println("No rented vehicles.");
                        }
                        else {
                        	rentedCars.forEach(System.out::println);
                        }
                    }
                    case 5 -> {
                        System.out.print("Vehicle ID: ");
                        System.out.println(repo.findCarById(sc.nextInt()));
                    }
                    case 6 -> {
                        System.out.print("First Name: "); String fn = sc.next();
                        System.out.print("Last Name: "); String ln = sc.next();
                        System.out.print("Email: "); String em = sc.next();
                        System.out.print("Phone: "); String ph = sc.next();
                        Customer c = new Customer(0, fn, ln, em, ph);
                        repo.addCustomer(c);
                        System.out.println("Customer added successfully.");
                    }
                    case 7 -> {
                        System.out.print("Customer ID: ");
                        int id = sc.nextInt();
                        repo.removeCustomer(id);
                        System.out.println("Customer with ID " + id + " has been removed.");
                    }
                    case 8 -> {
                        List<Customer> customers = repo.listCustomers();
                        if (customers.isEmpty()) System.out.println("No customers found.");
                        else customers.forEach(System.out::println);
                    }
                    case 9 -> {
                        System.out.print("Customer ID: ");
                        System.out.println(repo.findCustomerById(sc.nextInt()));
                    }
                    case 10 -> {
                        System.out.print("Customer ID: "); int custId = sc.nextInt();
                        System.out.print("Vehicle ID: "); int vehId = sc.nextInt();
                        System.out.print("Start Date (YYYY-MM-DD): "); LocalDate sd = LocalDate.parse(sc.next());
                        System.out.print("End Date (YYYY-MM-DD): "); LocalDate ed = LocalDate.parse(sc.next());
                        Lease lease = repo.createLease(custId, vehId, sd, ed);
                        System.out.println(" Lease created:\n" + lease);
                    }
                    case 11 -> {
                        System.out.print("Lease ID: ");
                        System.out.println("Vehicle returned:\n" + repo.returnCar(sc.nextInt()));
                    }
                    case 12 -> {
                        List<Lease> activeLeases = repo.listActiveLeases();
                        if (activeLeases.isEmpty()) {
                        	System.out.println("No active leases found.");                   
                        }
                        else {
                            System.out.println("Active Leases:");
                            activeLeases.forEach(System.out::println);
                        }
                    }
                    case 13 -> {
                        List<Lease> leaseHistory = repo.listLeaseHistory();
                        if (leaseHistory.isEmpty()) { 
                        	System.out.println("No lease history available.");
                        }
                        else {
                            System.out.println("Lease History:");
                            leaseHistory.forEach(System.out::println);
                        }
                    }
                    case 14 -> {
                        System.out.print("Lease ID: "); int lid = sc.nextInt();
                        Lease lease = repo.findLeaseById(lid);
                        System.out.print("Amount: "); double amt = sc.nextDouble();
                        repo.recordPayment(lease, amt);
                        System.out.println("Payment recorded successfully.");
                    }
                    case 15 -> {
                        List<Payment> payments = repo.listAllPayments();
                        if (payments.isEmpty()) {
                            System.out.println("No payment records found.");
                        } else {
                            System.out.println("=== Payment History ===");
                            for (Payment p : payments) {
                                System.out.println(p);
                            }
                        }
                        break; 
                    }
                    case 16 -> {
                        System.out.print("Enter Customer ID: ");
                        int customerId = sc.nextInt();
                        List<Payment> customerPayments = repo.getPaymentsByCustomerId(customerId);
                        if (customerPayments.isEmpty()) {
                            System.out.println("No payment history found for this customer.");
                        } else {
                            System.out.println("=== Payment History for Customer ID " + customerId + " ===");
                            customerPayments.forEach(System.out::println);
                        }
                    }

                    case 17 -> {
                        double totalRevenue = repo.calculateTotalRevenue();
                        System.out.printf("Total Revenue from all payments: ₹%.2f\n", totalRevenue);
                    }
                    case 18 -> {
                        System.out.print("Enter Customer ID: ");
                        int cid = sc.nextInt();
                        Lease activeLease = repo.getActiveLeaseByCustomerId(cid);
                        if (activeLease == null) {
                            System.out.println("No active lease found for this customer.");
                        } else {
                            System.out.println("Active Lease:\n" + activeLease);
                        }
                    }

                    case 0 -> System.out.println("Exiting... Thank you!");
                    default -> System.out.println("Invalid option. Please try again.");
                }
            } while (choice != 0);

        } catch (Exception e) {
            System.err.println("❗ Error during operation: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
