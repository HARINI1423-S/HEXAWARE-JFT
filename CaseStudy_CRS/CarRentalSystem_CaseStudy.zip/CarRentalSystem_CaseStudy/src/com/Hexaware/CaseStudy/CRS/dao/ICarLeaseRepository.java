package com.Hexaware.CaseStudy.CRS.dao;

import com.Hexaware.CaseStudy.CRS.entity.*;
import com.Hexaware.CaseStudy.CRS.exceptions.*;

import java.time.LocalDate;
import java.util.List;

public interface ICarLeaseRepository {

    // Car Management
    void addCar(Vehicle car);
    void removeCar(int carId) throws CarNotFoundException;
    List<Vehicle> listAvailableCars();
    List<Vehicle> listRentedCars();
    Vehicle findCarById(int carId) throws CarNotFoundException;

    // Customer Management
    void addCustomer(Customer customer);
    void removeCustomer(int customerId) throws CustomerNotFoundException;
    List<Customer> listCustomers();
    Customer findCustomerById(int customerId) throws CustomerNotFoundException;

    // Lease Management
    Lease createLease(int customerId, int carId, LocalDate startDate, LocalDate endDate) throws CarNotFoundException, CustomerNotFoundException;
    Lease returnCar(int leaseId) throws LeaseNotFoundException;
    List<Lease> listActiveLeases();
    List<Lease> listLeaseHistory();
    Lease getActiveLeaseByCustomerId(int customerId);

    // Payment Handling
    void recordPayment(Lease lease, double amount);
	Lease findLeaseById(int leaseID);
	List<Payment> listAllPayments();
	List<Payment> getPaymentsByCustomerId(int customerId);
	double calculateTotalRevenue();


}

