package com.Hexaware.CaseStudy.CRS.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    private static Connection connection = null;

    public static Connection getConnection(String propertyFile) {
        if (connection == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                String connStr = DBPropertyUtil.getPropertyString(propertyFile);
                connection = DriverManager.getConnection(connStr);
                System.out.println("Database Connection Established");
            } catch (ClassNotFoundException e) {
                System.err.println(" MySQL JDBC Driver not found: " + e.getMessage());
                throw new RuntimeException("JDBC Driver error", e);
            } catch (SQLException e) {
                System.err.println("Failed to connect to database: " + e.getMessage());
                throw new RuntimeException("Database connection failed", e);
            }
        }
        return connection;
    }
}
