package com.Hexaware.CaseStudy.CRS.exceptions;

public class LeaseNotFoundException extends RuntimeException {
    public LeaseNotFoundException(String message) {
        super(message);
    }
}
