package com.Hexaware.CaseStudy.CRS.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getPropertyString(String filename) {
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(filename)) {
            if (input == null) {
                throw new RuntimeException("Property file not found: " + filename);
            }

            Properties prop = new Properties();
            prop.load(input);

            String host = prop.getProperty("host");
            String port = prop.getProperty("port");
            String dbname = prop.getProperty("dbname");
            String username = prop.getProperty("username");
            String password = prop.getProperty("password");

            if (host == null || port == null || dbname == null || username == null || password == null) {
                throw new RuntimeException("Missing required database config values in " + filename);
            }

            return "jdbc:mysql://" + host + ":" + port + "/" + dbname +
                   "?user=" + username + "&password=" + password +
                   "&useSSL=false&allowPublicKeyRetrieval=true";

        } catch (IOException e) {
            throw new RuntimeException("Failed to load property file: " + filename, e);
        }
    }
}
