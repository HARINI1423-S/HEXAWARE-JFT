module CMS_Assignment {
	requires java.sql;
}