package com.Hexaware.CourierMangementSystem;
import java.util.*;
public class CMS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Task 1: Control Flow Statements
        OrderStatus.checkStatus("Delivered");
        ParcelCategorizer.categorizeParcel(4.5);
        UserAuthentication.login("admin", "password123");
        String[] couriers = {"Courier1", "Courier2", "Courier3"};
        CourierAssignment.assignCourier(couriers, 10);

        // Task 2: Loops and Iteration
        String[] orders = {"Order001", "Order002", "Order003"};
        OrderDisplay.displayOrders(orders);
        CourierTracking.trackLocation(5);

        // Task 3: Arrays and Data Structures
        String[] locations = {"New York", "Chicago", "Los Angeles"};
        ParcelTrackingHistory.storeTrackingHistory(locations);
        String[] courierNames = {"Courier A", "Courier B", "Courier C"};
        int[] distances = {15, 8, 10};
        System.out.println("Nearest courier: " + NearestCourierFinder.findNearestCourier(courierNames, distances));

        // Task 4: Strings, 2D Arrays, User Defined Functions, HashMap
        String[][] parcels = {
            {"TRK123", "In Transit"},
            {"TRK124", "Delivered"},
            {"TRK125", "Processing"}
        };
        ParcelTracker.trackParcel(parcels, "TRK124");

        System.out.println("Valid Name: " + CustomerValidation.validate("John", "name"));
        System.out.println("Valid Address: " + CustomerValidation.validate("123 Main St", "address"));
        System.out.println("Valid Phone: " + CustomerValidation.validate("123-456-7890", "phone"));

        System.out.println("Formatted Address: " + AddressFormatter.formatAddress("123 Main St", "New York", "NY", "10001"));

        OrderConfirmation.generateEmail("John Doe", "ORD456", "123 Main St, New York, NY - 10001", "April 10, 2025");

        System.out.println("Shipping Cost: $" + ShippingCostCalculator.calculateCost(200, 5.5));

        System.out.println("Generated Password: " + PasswordGenerator.generatePassword());

        System.out.println("Are addresses similar? " + AddressMatcher.areSimilar("123 Main St", "123 MAIN ST"));
    }
	
	// Task 1: Control Flow Statements

	// 1. Check Order Status using if-else
	
	class OrderStatus {
	    public static void checkStatus(String status) {
	        if (status.equalsIgnoreCase("Delivered")) {
	            System.out.println("Order has been delivered.");
	        } else if (status.equalsIgnoreCase("Processing")) {
	            System.out.println("Order is being processed.");
	        } else if (status.equalsIgnoreCase("Cancelled")) {
	            System.out.println("Order was cancelled.");
	        } else {
	            System.out.println("Invalid status.");
	        }
	    }
	}
	
	// 2. Categorize Parcels using Short Switch-Case
	
	class ParcelCategorizer {
	    public static void categorizeParcel(double weight) {
	        String category = switch ((int) weight) {
	            case 0, 1, 2 -> "Light";
	            case 3, 4, 5 -> "Medium";
	            default -> "Heavy";
	        };
	        System.out.println("The parcel is categorized as: " + category);
	    }
	}
	
	// 3. User Authentication
	
	class UserAuthentication {
	    public static boolean login(String username, String password) {
	        if (username.equals("admin") && password.equals("password123")) {
	            System.out.println("Login successful");
	            return true;
	        } else {
	            System.out.println("Invalid credentials");
	            return false;
	        }
	    }
	}
	
	// 4. Courier Assignment using Loops
	class CourierAssignment {
	    public static void assignCourier(String[] couriers, int maxCapacity) {
	        for (String courier : couriers) {
	            System.out.println("Assigning " + courier + " with max capacity: " + maxCapacity);
	        }
	    }
	}
	
	
	// Task 2: Loops and Iteration

	// 5. Display Orders using For Loop
	class OrderDisplay {
	    public static void displayOrders(String[] orders) {
	        for (String order : orders) {
	            System.out.println("Order: " + order);
	        }
	    }
	}

	// 6. Track Courier Location using While Loop
	class CourierTracking {
	    public static void trackLocation(int distance) {
	        int currentLocation = 0;
	        while (currentLocation < distance) {
	            System.out.println("Courier at location: " + currentLocation);
	            currentLocation++;
	        }
	        System.out.println("Courier reached the destination.");
	    }
	}
	
	// Task 3: Arrays and Data Structures

	// 7. Store tracking history in an array
	class ParcelTrackingHistory {
	    public static void storeTrackingHistory(String[] locations) {
	        for (String location : locations) {
	            System.out.println("Parcel passed through: " + location);
	        }
	    }
	}

	// 8. Find nearest available courier
	class NearestCourierFinder {
	    public static String findNearestCourier(String[] couriers, int[] distances) {
	        int minDistance = Integer.MAX_VALUE;
	        String nearestCourier = "";
	        for (int i = 0; i < couriers.length; i++) {
	            if (distances[i] < minDistance) {
	                minDistance = distances[i];
	                nearestCourier = couriers[i];
	            }
	        }
	        return nearestCourier;
	    }
	}

	// Task 4: Strings, 2D Arrays, User Defined Functions, HashMap

	// 9. Parcel Tracking using 2D String Array
	class ParcelTracker {
	    public static void trackParcel(String[][] parcels, String trackingNumber) {
	        for (String[] parcel : parcels) {
	            if (parcel[0].equals(trackingNumber)) {
	                System.out.println("Parcel Status: " + parcel[1]);
	                return;
	            }
	        }
	        System.out.println("Tracking number not found.");
	    }
	}

	// 10. Customer Data Validation
	class CustomerValidation {
	    public static boolean validate(String data, String detail) {
	        return switch (detail) {
	            case "name" -> data.matches("[A-Z][a-z]*");
	            case "address" -> data.matches("[A-Za-z0-9 ]+");
	            case "phone" -> data.matches("\\d{3}-\\d{3}-\\d{4}");
	            default -> false;
	        };
	    }
	}

	// 11. Address Formatting
	
	class AddressFormatter {
	    public static String formatAddress(String street, String city, String state, String zip) {
	        return street + ", " + city + ", " + state + " - " + zip;
	    }
	}

	// 12. Order Confirmation Email
	
	class OrderConfirmation {
	    public static void generateEmail(String name, String orderNo, String address, String date) {
	        System.out.println("Dear " + name + ",\nYour order " + orderNo + " will be delivered to " + address + " on " + date + ".");
	    }
	}

	// 13. Calculate Shipping Costs
	
	class ShippingCostCalculator {
	    public static double calculateCost(int distance, double weight) {
	        return distance * weight * 0.5;
	    }
	}

	// 14. Password Generator
	
	class PasswordGenerator {
	    public static String generatePassword() {
	        return "P@ssW0rd123!"; // Placeholder for complex logic
	    }
	}

	// 15. Find Similar Addresses
	
	class AddressMatcher {
	    public static boolean areSimilar(String addr1, String addr2) {
	        return addr1.equalsIgnoreCase(addr2);
	    }
	}
}

