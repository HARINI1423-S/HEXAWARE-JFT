package com.Hexaware.CourierManagementSystem.exception;

public class TrackingNumberNotFoundException extends Exception {
    
    public TrackingNumberNotFoundException() {
        super("Tracking number not found in the system.");
    }

    public TrackingNumberNotFoundException(String trackingNumber) {
        super("Tracking number not found: " + trackingNumber);
    }
}
