package com.Hexaware.CourierManagementSystem.util;
import java.sql.Connection;

public class DatabaseConnectionTest {
    public static void main(String[] args) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            System.out.println("Database connection is successful!");
        } else {
            System.out.println("Database connection failed!");
        }
    }
}