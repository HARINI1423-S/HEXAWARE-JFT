package com.Hexaware.CourierManagementSystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/CourierManagementSystem?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "Harini@1423";

    private DatabaseConnection() {} // Private constructor to prevent instantiation

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Optional for newer JDBC, but still good practice
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
        }

        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        System.out.println("Connection Established");
        return conn;
    }
}
