package com.Hexaware.CourierManagementSystem.dao;
import java.sql.SQLException;
import java.util.List;

import com.Hexaware.CourierManagementSystem.entity.Employee;
public interface EmployeeDao {
	  void addEmployee(Employee employee) throws SQLException;
	    Employee getEmployeeById(long employeeID) throws SQLException;
	    List<Employee> getAllEmployees() throws SQLException;

}
