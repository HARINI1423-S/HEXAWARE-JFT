package com.Hexaware.CourierManagementSystem.dao;

import java.sql.SQLException;

import com.Hexaware.CourierManagementSystem.entity.User;

public interface UserDao {
	 void addUser(User user) throws SQLException;
	    User getUserById(int userID) throws SQLException;

}
