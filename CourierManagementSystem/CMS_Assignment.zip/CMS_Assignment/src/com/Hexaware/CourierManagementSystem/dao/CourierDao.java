package com.Hexaware.CourierManagementSystem.dao;
import java.util.*;
import java.sql.SQLException;
import com.Hexaware.CourierManagementSystem.entity.Courier;
import com.Hexaware.CourierManagementSystem.exception.TrackingNumberNotFoundException;

public interface CourierDao {
    void addCourier(Courier courier) throws SQLException;
    Courier getCourierByTrackingNumber(String trackingNumber) throws SQLException, TrackingNumberNotFoundException;
    boolean updateCourierStatus(String trackingNumber, String status) throws SQLException;
    boolean deleteCourier(String trackingNumber) throws SQLException;
    public List<Courier> getAssignedOrdersByStaffId(long courierStaffId) throws SQLException;

    
    String saveOrder(Courier courier) throws SQLException;
   }
