package com.Hexaware.CourierManagementSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.Hexaware.CourierManagementSystem.entity.Courier;
import com.Hexaware.CourierManagementSystem.exception.CourierNotFoundException;
import com.Hexaware.CourierManagementSystem.exception.TrackingNumberNotFoundException;
import com.Hexaware.CourierManagementSystem.util.DatabaseConnection;

public class CourierDaoImpl implements CourierDao {

    @Override
    public void addCourier(Courier courier) throws SQLException {
        String trackingNumber = "ORD" + System.currentTimeMillis();
        String sql = "INSERT INTO Courier (tracking_number, sender_name) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, trackingNumber);
            stmt.setString(2, courier.getSenderName());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("DEBUG: Order inserted successfully! Tracking Number: " + trackingNumber);
            } else {
                System.out.println("ERROR: Order insertion failed.");
            }
        } catch (SQLException e) {
            System.out.println("SQL ERROR: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public Courier getCourierByTrackingNumber(String trackingNumber) throws SQLException, TrackingNumberNotFoundException {
        String sql = "SELECT * FROM Courier WHERE tracking_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, trackingNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Courier courier = new Courier();
                courier.setTrackingNumber(rs.getString("tracking_number"));
                courier.setSenderName(rs.getString("sender_name"));
                courier.setSenderAddress(rs.getString("sender_address"));
                courier.setReceiverName(rs.getString("receiver_name"));
                courier.setReceiverAddress(rs.getString("receiver_address"));
                courier.setWeight(rs.getDouble("weight"));
                courier.setStatus(rs.getString("status"));
                courier.setDeliveryDate(rs.getDate("delivery_date"));
                return courier;
            } else {
                throw new TrackingNumberNotFoundException(trackingNumber);
            }
        }
    }

    @Override
    public boolean updateCourierStatus(String trackingNumber, String status) throws SQLException {
        String sql = "UPDATE Courier SET status = ? WHERE tracking_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setString(2, trackingNumber);

            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteCourier(String trackingNumber) throws SQLException {
        String sql = "DELETE FROM Courier WHERE tracking_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, trackingNumber);
            return stmt.executeUpdate() > 0;
        }
    }

    @Override
    public String saveOrder(Courier courier) throws SQLException {
        String trackingNumber = "ORD" + System.currentTimeMillis();
        String sql = "INSERT INTO Courier (sender_name, sender_address, receiver_name, receiver_address, weight, status, tracking_number, delivery_date) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, courier.getSenderName());
            stmt.setString(2, courier.getSenderAddress());
            stmt.setString(3, courier.getReceiverName());
            stmt.setString(4, courier.getReceiverAddress());
            stmt.setDouble(5, courier.getWeight());
            stmt.setString(6, courier.getStatus());
            stmt.setString(7, trackingNumber);
            stmt.setDate(8, new java.sql.Date(System.currentTimeMillis()));

            int rowsAffected = stmt.executeUpdate();
            return (rowsAffected > 0) ? trackingNumber : null;
        }
    }

    @Override
    public List<Courier> getAssignedOrdersByStaffId(long courierStaffId) throws SQLException {
        List<Courier> orders = new ArrayList<>();
        String sql = "SELECT * FROM Courier WHERE assigned_staff_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, courierStaffId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Courier courier = new Courier(
                    rs.getInt("courier_id"),
                    rs.getString("sender_name"),
                    rs.getString("sender_address"),
                    rs.getString("receiver_name"),
                    rs.getString("receiver_address"),
                    rs.getDouble("weight"),
                    rs.getString("status"),
                    rs.getString("tracking_number"),
                    rs.getDate("delivery_date")
                );
                orders.add(courier);
            }
        }
        return orders;
    }

    public String placeOrder(Courier courier) throws CourierNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;
        String trackingNumber = "TRK" + System.currentTimeMillis();

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Courier (sender_name, sender_address, receiver_name, receiver_address, weight, status, tracking_number, delivery_date) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            stmt = conn.prepareStatement(sql);
            stmt.setString(1, courier.getSenderName());
            stmt.setString(2, courier.getSenderAddress());
            stmt.setString(3, courier.getReceiverName());
            stmt.setString(4, courier.getReceiverAddress());
            stmt.setDouble(5, courier.getWeight());
            stmt.setString(6, courier.getStatus());
            stmt.setString(7, trackingNumber);
            stmt.setDate(8, new java.sql.Date(System.currentTimeMillis()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                return trackingNumber;
            } else {
                throw new CourierNotFoundException("Failed to insert courier record.");
            }

        } catch (SQLException e) {
            throw new CourierNotFoundException("Database error while placing order: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
