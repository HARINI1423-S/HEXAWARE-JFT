package com.Hexaware.CourierManagementSystem.service;
import com.Hexaware.CourierManagementSystem.entity.*;
import com.Hexaware.CourierManagementSystem.exception.*;
import java.util.List;

import com.Hexaware.CourierManagementSystem.entity.Courier;

public interface ICourierUserService {
    String placeOrder(Courier courier) throws CourierNotFoundException;
    String getOrderStatus(String trackingNumber) throws CourierNotFoundException;
    boolean cancelOrder(String trackingNumber) throws CourierNotFoundException;
    List<Courier> getAssignedOrder(long courierStaffId);
}
