package com.Hexaware.CourierManagementSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.Hexaware.CourierManagementSystem.dao.CourierDao;
import com.Hexaware.CourierManagementSystem.dao.CourierDaoImpl;
import com.Hexaware.CourierManagementSystem.entity.Courier;
import com.Hexaware.CourierManagementSystem.exception.CourierNotFoundException;

public class CourierService implements ICourierUserService {
    private CourierDao courierDao = new CourierDaoImpl(); // DAO object

    @Override
    public String placeOrder(Courier courier) throws CourierNotFoundException {
        try {
            String trackingNumber = courierDao.saveOrder(courier);
            if (trackingNumber == null) {
                throw new CourierNotFoundException("Order could not be placed.");
            }
            return trackingNumber;
        } catch (SQLException e) {
            throw new CourierNotFoundException("Database error while placing order: " + e.getMessage());
        }
    }

    @Override
    public String getOrderStatus(String trackingNumber) throws CourierNotFoundException {
        try {
            Courier courier = courierDao.getCourierByTrackingNumber(trackingNumber);
            if (courier == null) {
                throw new CourierNotFoundException("Courier not found with tracking number: " + trackingNumber);
            }
            return courier.getStatus();
        } catch (SQLException e) {
            throw new CourierNotFoundException("Database error while retrieving order status: " + e.getMessage());
        }
    }

    @Override
    public boolean cancelOrder(String trackingNumber) throws CourierNotFoundException {
        try {
            boolean isDeleted = courierDao.deleteCourier(trackingNumber);
            if (!isDeleted) {
                throw new CourierNotFoundException("Failed to cancel order. Tracking number not found.");
            }
            return true;
        } catch (SQLException e) {
            throw new CourierNotFoundException("Database error while canceling order: " + e.getMessage());
        }
    }

    @Override
    public List<Courier> getAssignedOrder(long courierStaffId) {
        try {
            return courierDao.getAssignedOrdersByStaffId(courierStaffId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
   
}
