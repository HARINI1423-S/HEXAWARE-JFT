package com.Hexaware.CourierManagementSystem.service;
import java.util.List;
import com.Hexaware.CourierManagementSystem.entity.*;
import com.Hexaware.CourierManagementSystem.exception.*;


public interface ICourierAdminService {
    int addCourierStaff(Employee obj) throws InvalidEmployeeIdException;
}
