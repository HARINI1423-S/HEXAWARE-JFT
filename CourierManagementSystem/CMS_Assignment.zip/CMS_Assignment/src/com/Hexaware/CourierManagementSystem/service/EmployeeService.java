package com.Hexaware.CourierManagementSystem.service;

import com.Hexaware.CourierManagementSystem.entity.Employee;


	public class EmployeeService implements ICourierAdminService {
	    @Override
	    public int addCourierStaff(Employee obj) {
	        // Implementation logic
	        return 1;
	    }
	}


