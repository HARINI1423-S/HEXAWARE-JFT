package com.Hexaware.CourierManagementSystem.main;

import java.util.Scanner;
import com.Hexaware.CourierManagementSystem.exception.CourierNotFoundException;
import com.Hexaware.CourierManagementSystem.entity.Courier;
import com.Hexaware.CourierManagementSystem.entity.Employee;
import com.Hexaware.CourierManagementSystem.service.CourierService;
import com.Hexaware.CourierManagementSystem.service.EmployeeService;

public class App {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CourierService courierService = new CourierService();
        EmployeeService employeeService = new EmployeeService();

        while (true) {
            System.out.println("\n====== Courier Management System ======");
            System.out.println("1. Place Order");
            System.out.println("2. Get Order Status");
            System.out.println("3. Cancel Order");
            System.out.println("4. Add Courier Staff");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        try {
                            System.out.println("\nEnter sender name:");
                            String senderName = scanner.nextLine();
                            
                            System.out.println("Enter sender address:");
                            String senderAddress = scanner.nextLine();

                            System.out.println("Enter receiver name:");
                            String receiverName = scanner.nextLine();

                            System.out.println("Enter receiver address:");
                            String receiverAddress = scanner.nextLine();

                            System.out.println("Enter package weight (in kg):");
                            double weight = scanner.nextDouble();
                            scanner.nextLine(); // consume newline

                            Courier courier = new Courier();
                            courier.setSenderName(senderName);
                            courier.setSenderAddress(senderAddress);
                            courier.setReceiverName(receiverName);
                            courier.setReceiverAddress(receiverAddress);
                            courier.setWeight(weight);
                            courier.setStatus("Placed");

                            String trackingNumber = courierService.placeOrder(courier);

                            if (trackingNumber != null) {
                                System.out.println("✅ Order placed successfully! Tracking number: " + trackingNumber);
                            } else {
                                System.out.println("❌ Failed to place order. Please try again.");
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            System.out.println("❌ Error while placing order: " + ex.getMessage());
                            scanner.nextLine(); // clear scanner buffer
                        }
                        break;

                    case 2:
                        System.out.println("\nEnter tracking number:");
                        String trackNum = scanner.nextLine();
                        try {
                            String status = courierService.getOrderStatus(trackNum);
                            System.out.println("📦 Order Status: " + status);
                        } catch (CourierNotFoundException e) {
                            System.out.println("⚠️ Error: " + e.getMessage());
                        }
                        break;

                    case 3:
                        System.out.println("\nEnter tracking number to cancel:");
                        String cancelTrack = scanner.nextLine();
                        try {
                            if (courierService.cancelOrder(cancelTrack)) {
                                System.out.println("✅ Order canceled successfully.");
                            } else {
                                System.out.println("❌ Failed to cancel order. Order might not exist.");
                            }
                        } catch (CourierNotFoundException e) {
                            System.out.println("⚠️ Error: " + e.getMessage());
                        }
                        break;
                    case 4:
                        System.out.println("\nEnter employee name:");
                        String empName = scanner.nextLine();
                        Employee emp = new Employee();
                        emp.setEmployeeName(empName);

                        int empId = employeeService.addCourierStaff(emp);
                        System.out.println("👨‍💼 Courier staff added successfully! Employee ID: " + empId);
                        break;

                    case 5:
                        System.out.println("🚪 Exiting the system...");
                        scanner.close();
                        return;

                    default:
                        System.out.println("⚠️ Invalid choice! Please enter a valid option.");
                }
            } catch (Exception e) {
                System.out.println("⚠️ Invalid input! Please enter a valid number.");
                scanner.nextLine(); // clear invalid input
            }
        }
    }
}

