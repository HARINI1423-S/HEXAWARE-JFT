package com.Hexaware.main;

import com.Hexaware.dao.*;
import com.Hexaware.entity.*;
import com.Hexaware.exception.*;

import java.io.File;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;

public class MainModule {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DatabaseManager dbManager = new DatabaseManagerImpl();
        dbManager.initializeDatabase();

        System.out.println("Database connection established successfully!");

        while (true) {
            System.out.println("\n=== CareerHub Menu ===");
            System.out.println("1. Add Company");
            System.out.println("2. Post Job");
            System.out.println("3. Register Applicant");
            System.out.println("4. Apply for Job");
            System.out.println("5. View Job Listings");
            System.out.println("6. Search Jobs by Salary Range");
            System.out.println("7. Calculate Average Salary");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Company ID: ");
                    int compId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Company Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Location: ");
                    String loc = scanner.nextLine();
                    dbManager.insertCompany(new Company(compId, name, loc));
                    break;

                case 2:
                    try {
                        System.out.print("Enter Job ID: ");
                        int jobId = scanner.nextInt();

                        System.out.print("Enter Company ID: ");
                        int companyId = scanner.nextInt();
                        scanner.nextLine();

                        System.out.print("Enter Job Title: ");
                        String title = scanner.nextLine();

                        System.out.print("Enter Job Description: ");
                        String desc = scanner.nextLine();

                        System.out.print("Enter Job Location: ");
                        String jobLoc = scanner.nextLine();

                        System.out.print("Enter Salary: ");
                        double salary = scanner.nextDouble();
                        if (salary < 0) {
                            throw new InvalidSalaryException("Salary cannot be negative!");
                        }
                        scanner.nextLine();

                        System.out.print("Enter Job Type (Full-time/Part-time): ");
                        String type = scanner.nextLine();

                        LocalDateTime postedDate = LocalDateTime.now();

                        JobListing job = new JobListing(jobId, companyId, title, desc, jobLoc, salary, type, postedDate);
                        dbManager.insertJobListing(job);
                    } catch (InvalidSalaryException e) {
                        System.out.println("Error: " + e.getMessage());
                    } catch (Exception e) {
                        System.out.println("An error occurred: " + e.getMessage());
                    }
                    break;

                case 3:
                    try {
                        System.out.print("Enter Applicant ID: ");
                        int appId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter First Name: ");
                        String fName = scanner.nextLine();
                        System.out.print("Enter Last Name: ");
                        String lName = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        String email = scanner.nextLine();
                        if (!Pattern.matches("^[\\w.-]+@[\\w.-]+\\.\\w+$", email)) {
                            throw new InvalidEmailException("Invalid email format!");
                        }
                        System.out.print("Enter Phone: ");
                        String phone = scanner.nextLine();
                        System.out.print("Enter Resume File Path: ");
                        String resumePath = scanner.nextLine();
                        File resumeFile = new File(resumePath);
                        if (!resumeFile.exists() || !resumeFile.isFile()) {
                            throw new FileUploadException("Resume file not found.");
                        }
                        if (resumeFile.length() > 1024 * 1024) {
                            throw new FileUploadException("Resume file size exceeded 1MB.");
                        }

                        dbManager.insertApplicant(new Applicant(appId, fName, lName, email, phone, resumePath));
                    } catch (InvalidEmailException | FileUploadException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4:
                    try {
                        System.out.print("Enter Application ID: ");
                        int applId = scanner.nextInt();
                        System.out.print("Enter Job ID: ");
                        int jobApplyId = scanner.nextInt();
                        System.out.print("Enter Applicant ID: ");
                        int applicantId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Cover Letter: ");
                        String cover = scanner.nextLine();

                        JobApplication application = new JobApplication(
                                applId,
                                jobApplyId,
                                applicantId,
                                LocalDateTime.now(),
                                cover
                        );

                        dbManager.insertJobApplication(application);
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 5:
                    List<JobListing> listings = dbManager.getJobListings();
                    for (JobListing listing : listings) {
                        System.out.printf("ID: %d | Title: %s | Location: %s | Salary: %.2f | Type: %s%n",
                                listing.getJobID(), listing.getJobTitle(), listing.getJobLocation(),
                                listing.getSalary(), listing.getJobType());
                    }
                    break;

                case 6:
                    System.out.print("Enter minimum salary: ");
                    double minSalary = scanner.nextDouble();
                    System.out.print("Enter maximum salary: ");
                    double maxSalary = scanner.nextDouble();
                    List<JobListing> filteredJobs = dbManager.searchJobsBySalaryRange(minSalary, maxSalary);
                    System.out.println("\nJobs within salary range:");
                    for (JobListing jobItem : filteredJobs) {
                        System.out.printf("ID: %d | Title: %s | Salary: %.2f | Type: %s | Location: %s%n",
                                jobItem.getJobID(), jobItem.getJobTitle(), jobItem.getSalary(),
                                jobItem.getJobType(), jobItem.getJobLocation());
                    }
                    break;

                case 7:
                    try {
                        List<JobListing> jobs = dbManager.getJobListings();
                        double total = 0;
                        int count = 0;
                        for (JobListing jobItem : jobs) {
                            if (jobItem.getSalary() < 0) {
                                throw new InvalidSalaryException("Job ID " + jobItem.getJobID() + " has negative salary!");
                            }
                            total += jobItem.getSalary();
                            count++;
                        }
                        double average = (count > 0) ? total / count : 0;
                        System.out.printf("Average Salary: %.2f%n", average);
                    } catch (InvalidSalaryException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 8:
                    System.out.println("Exiting... Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
