package com.Hexaware.util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {

    public static Properties getProperties(String fileName) {
        Properties prop = new Properties();
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(fileName)) {
            if (input == null) {
                throw new RuntimeException("Unable to find " + fileName);
            }
            prop.load(input);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return prop;
    }
}



