package com.Hexaware.dao;

import com.Hexaware.entity.*;
import com.Hexaware.util.*;
import java.sql.*;
import java.util.*;

public class DatabaseManagerImpl implements DatabaseManager {

    private Connection getConnection() throws SQLException {
        Properties props = DBPropertyUtil.getProperties("db.properties");
        String url = props.getProperty("db.url");
        String user = props.getProperty("db.user");
        String password = props.getProperty("db.password");
        return DBConnUtil.getConnection(url, user, password);
    }

    @Override
    public void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {

            String createCompanies = "CREATE TABLE IF NOT EXISTS Companies (" +
                    "CompanyID INT PRIMARY KEY," +
                    "CompanyName VARCHAR(100)," +
                    "Location VARCHAR(100))";

            String createJobs = "CREATE TABLE IF NOT EXISTS Jobs (" +
                    "JobID INT PRIMARY KEY," +
                    "CompanyID INT," +
                    "JobTitle VARCHAR(100)," +
                    "JobDescription TEXT," +
                    "JobLocation VARCHAR(100)," +
                    "Salary DECIMAL(10,2)," +
                    "JobType VARCHAR(50)," +
                    "PostedDate TIMESTAMP," +
                    "FOREIGN KEY (CompanyID) REFERENCES Companies(CompanyID))";

            String createApplicants = "CREATE TABLE IF NOT EXISTS Applicants (" +
                    "ApplicantID INT PRIMARY KEY," +
                    "FirstName VARCHAR(50)," +
                    "LastName VARCHAR(50)," +
                    "Email VARCHAR(100)," +
                    "Phone VARCHAR(20)," +
                    "Resume TEXT)";

            String createApplications = "CREATE TABLE IF NOT EXISTS Applications (" +
                    "ApplicationID INT PRIMARY KEY," +
                    "JobID INT," +
                    "ApplicantID INT," +
                    "ApplicationDate TIMESTAMP," +
                    "CoverLetter TEXT," +
                    "FOREIGN KEY (JobID) REFERENCES Jobs(JobID)," +
                    "FOREIGN KEY (ApplicantID) REFERENCES Applicants(ApplicantID))";

            stmt.execute(createCompanies);
            stmt.execute(createJobs);
            stmt.execute(createApplicants);
            stmt.execute(createApplications);

            System.out.println("Database initialized successfully.");

        } catch (SQLException e) {
            System.out.println("Database initialization error: " + e.getMessage());
        }
    }

    @Override
    public void insertJobListing(JobListing job) {
        String sql = "INSERT INTO Jobs VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, job.getJobID());
            stmt.setInt(2, job.getCompanyID());
            stmt.setString(3, job.getJobTitle());
            stmt.setString(4, job.getJobDescription());
            stmt.setString(5, job.getJobLocation());
            stmt.setDouble(6, job.getSalary());
            stmt.setString(7, job.getJobType());
            stmt.setTimestamp(8, Timestamp.valueOf(job.getPostedDate()));
            stmt.executeUpdate();
            System.out.println("Job listing inserted successfully.");
        } catch (SQLException e) {
            System.out.println("Error inserting job listing: " + e.getMessage());
        }
    }

    @Override
    public void insertCompany(Company company) {
        String checkSql = "SELECT COUNT(*) FROM Companies WHERE CompanyID = ?";
        String insertSql = "INSERT INTO Companies (CompanyID, CompanyName, Location) VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {

            checkStmt.setInt(1, company.getCompanyID());
            ResultSet rs = checkStmt.executeQuery();
            rs.next();

            if (rs.getInt(1) > 0) {
                System.out.println("Company with ID " + company.getCompanyID() + " already exists.");
                return;
            }

            try (PreparedStatement stmt = conn.prepareStatement(insertSql)) {
                stmt.setInt(1, company.getCompanyID());
                stmt.setString(2, company.getCompanyName());
                stmt.setString(3, company.getLocation());
                stmt.executeUpdate();
                System.out.println("Company added successfully.");
            }

        } catch (SQLException e) {
            System.out.println("Error inserting company: " + e.getMessage());
        }
    }

    @Override
    public void insertApplicant(Applicant applicant) {
        String sql = "INSERT INTO Applicants VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, applicant.getApplicantID());
            stmt.setString(2, applicant.getFirstName());
            stmt.setString(3, applicant.getLastName());
            stmt.setString(4, applicant.getEmail());
            stmt.setString(5, applicant.getPhone());
            stmt.setString(6, applicant.getResume());
            stmt.executeUpdate();
            System.out.println("Applicant registered successfully.");
        } catch (SQLException e) {
            System.out.println("Error inserting applicant: " + e.getMessage());
        }
    }

    @Override
    public void insertJobApplication(JobApplication application) {
        String sql = "INSERT INTO Applications VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, application.getApplicationID());
            stmt.setInt(2, application.getJobID());
            stmt.setInt(3, application.getApplicantID());
            stmt.setTimestamp(4, Timestamp.valueOf(application.getApplicationDate()));
            stmt.setString(5, application.getCoverLetter());
            stmt.executeUpdate();
            System.out.println("Job application submitted successfully.");
        } catch (SQLException e) {
            System.out.println("Error inserting job application: " + e.getMessage());
        }
    }

    @Override
    public List<JobListing> getJobListings() {
        List<JobListing> jobs = new ArrayList<>();
        String sql = "SELECT * FROM Jobs";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JobListing job = new JobListing(
                        rs.getInt("JobID"),
                        rs.getInt("CompanyID"),
                        rs.getString("JobTitle"),
                        rs.getString("JobDescription"),
                        rs.getString("JobLocation"),
                        rs.getDouble("Salary"),
                        rs.getString("JobType"),
                        rs.getTimestamp("PostedDate").toLocalDateTime()
                );
                jobs.add(job);
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving job listings: " + e.getMessage());
        }

        return jobs;
    }

    @Override
    public List<Company> getCompanies() {
        List<Company> companies = new ArrayList<>();
        String sql = "SELECT * FROM Companies";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Company company = new Company(
                        rs.getInt("CompanyID"),
                        rs.getString("CompanyName"),
                        rs.getString("Location")
                );
                companies.add(company);
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving companies: " + e.getMessage());
        }

        return companies;
    }

    @Override
    public List<Applicant> getApplicants() {
        List<Applicant> applicants = new ArrayList<>();
        String sql = "SELECT * FROM Applicants";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Applicant applicant = new Applicant(
                        rs.getInt("ApplicantID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("Phone"),
                        rs.getString("Resume")
                );
                applicants.add(applicant);
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving applicants: " + e.getMessage());
        }

        return applicants;
    }

    @Override
    public List<JobApplication> getApplicationsForJob(int jobID) {
        List<JobApplication> applications = new ArrayList<>();
        String sql = "SELECT * FROM Applications WHERE JobID = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, jobID);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JobApplication app = new JobApplication(
                            rs.getInt("ApplicationID"),
                            rs.getInt("JobID"),
                            rs.getInt("ApplicantID"),
                            rs.getTimestamp("ApplicationDate").toLocalDateTime(),
                            rs.getString("CoverLetter")
                    );
                    applications.add(app);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving job applications: " + e.getMessage());
        }

        return applications;
    }

    @Override
    public List<JobListing> searchJobsBySalaryRange(double minSalary, double maxSalary) {
        List<JobListing> jobsInRange = new ArrayList<>();
        String sql = "SELECT * FROM Jobs WHERE Salary BETWEEN ? AND ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, minSalary);
            stmt.setDouble(2, maxSalary);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JobListing job = new JobListing(
                            rs.getInt("JobID"),
                            rs.getInt("CompanyID"),
                            rs.getString("JobTitle"),
                            rs.getString("JobDescription"),
                            rs.getString("JobLocation"),
                            rs.getDouble("Salary"),
                            rs.getString("JobType"),
                            rs.getTimestamp("PostedDate").toLocalDateTime()
                    );
                    jobsInRange.add(job);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error searching jobs by salary range: " + e.getMessage());
        }

        return jobsInRange;
    }
}
