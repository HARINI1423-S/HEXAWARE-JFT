package com.Hexaware.dao;

import java.util.List;
import com.Hexaware.entity.*;

public interface DatabaseManager {
    void initializeDatabase();
    void insertJobListing(JobListing job);
    void insertCompany(Company company);
    void insertApplicant(Applicant applicant);
    void insertJobApplication(JobApplication application);
    List<JobListing> getJobListings();
    List<Company> getCompanies();
    List<Applicant> getApplicants();
    List<JobListing> searchJobsBySalaryRange(double minSalary, double maxSalary);
    List<JobApplication> getApplicationsForJob(int jobID);
}