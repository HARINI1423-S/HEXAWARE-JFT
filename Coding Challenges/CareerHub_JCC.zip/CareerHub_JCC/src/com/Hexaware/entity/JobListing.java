package com.Hexaware.entity;

import java.time.LocalDateTime;

public class JobListing {
    private int jobID;
    private int companyID;
    private String jobTitle;
    private String jobDescription;
    private String jobLocation;
    private double salary;
    private String jobType;
    private LocalDateTime postedDate;

    public JobListing(int jobID, int companyID, String jobTitle, String jobDescription, String jobLocation,
                      double salary, String jobType, LocalDateTime postedDate) {
        this.jobID = jobID;
        this.companyID = companyID;
        this.jobTitle = jobTitle;
        this.jobDescription = jobDescription;
        this.jobLocation = jobLocation;
        this.salary = salary;
        this.jobType = jobType;
        this.postedDate = postedDate;
    }

    // Getters
    public int getJobID() {
        return jobID;
    }

    public int getCompanyID() {
        return companyID;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public String getJobLocation() {
        return jobLocation;
    }

    public double getSalary() {
        return salary;
    }

    public String getJobType() {
        return jobType;
    }

    public LocalDateTime getPostedDate() {
        return postedDate;
    }

    // Setters
    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public void setJobLocation(String jobLocation) {
        this.jobLocation = jobLocation;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public void setPostedDate(LocalDateTime postedDate) {
        this.postedDate = postedDate;
    }

    @Override
    public String toString() {
        return String.format("ID: %d | Title: %s | Location: %s | Salary: %.2f | Type: %s",
                jobID, jobTitle, jobLocation, salary, jobType);
    }
}

