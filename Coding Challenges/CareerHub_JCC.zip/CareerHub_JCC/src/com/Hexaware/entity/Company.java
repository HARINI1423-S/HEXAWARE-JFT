package com.Hexaware.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Company {
    private int companyID;
    private String companyName;
    private String location;
    private List<JobListing> jobs;

    public Company() {
        this.jobs = new ArrayList<>();
    }

    public Company(int companyID, String companyName, String location) {
        this.companyID = companyID;
        this.companyName = companyName;
        this.location = location;
        this.jobs = new ArrayList<>();
    }

    public int getCompanyID() { 
    	return companyID; 
    	}
    public void setCompanyID(int companyID) {
    	this.companyID = companyID; 
    	}
    public String getCompanyName() {
    	return companyName; 
    	}
    public void setCompanyName(String companyName) {
    	this.companyName = companyName; 
    	}
    public String getLocation() { 
    	return location; 
    	}
    public void setLocation(String location) { 
    	this.location = location;
    	}

    public void postJob(String jobTitle, String jobDescription, String jobLocation, double salary, String jobType) {
        JobListing job = new JobListing(0, companyID, jobTitle, jobDescription, jobLocation, salary, jobType, LocalDateTime.now());
        jobs.add(job);
    }

    public List<JobListing> getJobs() {
        return jobs;
    }
}