module CareerHub_JCC {
	requires java.sql;
}